def lambda_handler(event, context):
    # Your code logic here
    return {
        'statusCode': 200,
        'body': 'Hello from Lambda!'
    }